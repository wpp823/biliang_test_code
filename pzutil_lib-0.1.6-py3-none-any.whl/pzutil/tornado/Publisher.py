import requests
import json
import asyncio
import aiohttp
import functools
# import nest_asyncio as nt_asyncio
import redis

# nt_asyncio.apply()

# REDIS_IP = '192.168.1.202'
# REDIS_PORT = 6379
# REDIS_DB = 0
# REDIS_PASSWORD = None

REDIS_DB = 8
REDIS_PASSWORD = "Pzzh4Admin"
REDIS_IP = "r-wz9ecc5cdf5821c4.redis.rds.aliyuncs.com"
REDIS_PORT = 6379
max_connections=20

pool = redis.ConnectionPool(
        host=REDIS_IP,
        port=REDIS_PORT,
        db=REDIS_DB,
        password=REDIS_PASSWORD,
        max_connections=max_connections,
        decode_responses=True,
    )
redis_db = redis.Redis(connection_pool=pool)

class Publisher:

    def __init__(self, project, handler_name, log=None):
        """

        :param redis:
        :param project: 订阅项目
        :param handler_name: 订阅handler
        :return:
        """
        self.observers = set()
        self._redis = redis_db
        self._rds_key = 'pub_{}_{}'.format(project, handler_name)
        self._params = None     # 请求参数
        self._log = log

    @property
    def params(self):
        return self._params

    @params.setter
    def params(self, params):
        self._params = params

    def add_observer(self, callback):
        """
        增加订阅url
        :param callback:
        :return:
        """

        ob_list = self.get_observer_list()

        ob_list = ob_list if ob_list else []

        ob_list.append(callback)

        self._redis.set(self._rds_key, json.dumps(ob_list))

    def get_observer_list(self):
        """
        获取订阅列表
        :return:
        """
        list_str = self._redis.get(self._rds_key)

        ob_list = json.loads(list_str)

        return ob_list

    def remove(self, callback):
        try:
            observers = self.get_observer_list()

            observers.remove(callback)
        except ValueError:
            print('Failed to remove: {}'.format(callback))

    def add_key_observer(self, key, callback):
        """
        增加监听回调
        :param key: 指定key
        :param callback: 回调url
        ob_items:{key:[callback1,callback2]}
        :return:
        """
        ob_items = self.get_observer_items()

        if ob_items:
            has_key = False
            for c_key, c_list in ob_items.items():
                if c_key == key:
                    c_list.append(callback)

                    c_list = list(set(c_list))

                    ob_items[key] = c_list
                    has_key = True

            if not has_key:
                ob_items[key] = [callback]
        else:
            ob_items = {key: [callback]}

        self._redis.set(self._rds_key, json.dumps(ob_items))

    def get_observer_items(self):

        list_items_str = self._redis.get(self._rds_key)
        self._log.info('[Publisher][get_observer_items][{}]'.format(list_items_str))
        if list_items_str:
            list_items = json.loads(list_items_str)
        else:
            list_items = {}

        return list_items

    def notify_get(self, key):

        observers = self.get_observer_items()
        # todo 重试, 移除
        for c_key, c_list in observers.items():
            if c_key == key:
                for callback in c_list:
                    requests.get(callback, params=self._params)

    def notify_post(self, key, params):

        observers = self.get_observer_items()
        data = {
            'params': params
        }

        for c_key, c_list in observers.items():
            if c_key == key:
                for callback in c_list:
                    requests.post(callback, data=data, timeout=10)
                    if self._log:
                        self._log.info('[Publisher][notify_post][callback:{}, data:{}]'.format(callback, data))

    def notify_get_async(self, key):
        """
        异步调用
        :param key: 回调对应的key
        :return:
        """
        observers = self.get_observer_items()
        loop = asyncio.get_event_loop()

        tasks = []
        for c_key, c_list in observers.items():
            if c_key == key:
                for callback in c_list:
                    tasks.append(self.do_callback(callback))

        loop.run_until_complete(asyncio.wait(tasks))
        loop.close()

        # await asyncio.gather(tasks)
        # loop.run_until_complete(asyncio.wait(tasks))
        # loop.close()

    def notify_post_async(self, key, params=None):
        """
        异步调用
        :param key: 回调对应的key
        :return:
        """

        loop = asyncio.get_event_loop()
        observers = self.get_observer_items()

        tasks = []
        for c_key, c_list in observers.items():
            if c_key == key:
                for callback in c_list:
                    tasks.append(self.do_post_callback(callback, params))

        loop.run_until_complete(asyncio.wait(tasks))
        loop.close()

    async def do_callback(self, url):

        data = {
            'params': self._params
        }

        async with aiohttp.request('GET', url) as r:
            await r.text()

        # future = asyncio.get_event_loop().run_in_executor(None, functools.partial(requests.get, url, data=data))
        # # future = asyncio.get_running_loop().run_in_executor(None, functools.partial(requests.get, url, data=data))
        #
        # response = await future
        # print(response.text)

    async def do_post_callback(self, url, params):

        data = {
            'params': params
        }

        future = asyncio.get_event_loop().run_in_executor(None, functools.partial(requests.post, url, data=data))

        response = await future
        print(response.text)

class DefaultFormatter(Publisher):

    def __init__(self, redis, project, handler_name):
        Publisher.__init__(self, redis=redis, project=project, handler_name=handler_name)
        # self.name = name
        self._data = 0

    # def __str__(self):
    #     return "{}: '{}' has data = {}".format(type(self).__name__, self.name, self._data)

    @property
    def data(self):
        return self._data

    def del_user(self):
        try:
            # todo 删除用户
            pass
        except ValueError as e:
            print('Error: {}'.format(e))
        else:
            self.notify_get()


if __name__ == '__main__':
    pub = Publisher('test','test')
    # pub.add_key_observer('test_an','http://www.baidu.com')

    pub.notify_post_async('test_an', params='test')

    # import os
    # async def do_post_test_callback(url):
    #     data = {
    #         'params': {}
    #     }
    #
    #     future = asyncio.get_event_loop().run_in_executor(None, functools.partial(requests.post, url, data=data))
    #
    #     response = await future
    #     print(response.text)
    #
    # tasks = [do_post_test_callback('http://www.baidu.com')]
    # loop = asyncio.get_event_loop()
    # loop.run_until_complete(asyncio.wait(tasks))
    # loop.close()

    # async def crawler(url):
    #     print('Start crawling:', url)
    #     headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36'}
    #
    #     future = asyncio.get_event_loop().run_in_executor(None, functools.partial(requests.post, url,data={}, headers=headers))
    #
    #     response = await future
    #
    #     print('Response received:', url)
    #     print(response.text)
    #
    # async def test(url):
    #     async with aiohttp.request('GET', url) as resp:
    #         json = await resp.text()
    #         print(json)
    #
    # loop = asyncio.get_event_loop()
    #
    # # tasks = [crawler('http://www.baidu.com'), crawler('http://www.sina.com')]
    # tasks = [test('http://www.baidu.com')]
    #
    # loop.run_until_complete(asyncio.wait(tasks))
    # loop.close()