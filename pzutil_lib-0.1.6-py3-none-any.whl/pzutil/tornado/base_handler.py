
from torndsession.sessionhandler import SessionBaseHandler
from pzutil.common.session import CeSessionManager

from opentracing.propagation import Format
from opentracing_instrumentation.request_context import get_current_span, span_in_context
from opentracing.ext import tags
from urllib.parse import urlparse

import functools

def trace():
    def decorator(func):
        @functools.wraps(func)
        def wrapper(self,*args, **kw):
            request = self.request
            try:
                # Create a new span context, reading in values (traceid,
                # spanid, etc) from the incoming x-b3-*** headers.
                span_ctx = self.application.tracer.extract(
                    Format.HTTP_HEADERS,
                    dict(request.headers)
                )
                # Note: this tag means that the span will *not* be
                # a child span. It will use the incoming traceid and
                # spanid. We do this to propagate the headers verbatim.
                rpc_tag = {tags.SPAN_KIND: tags.SPAN_KIND_RPC_SERVER}
                span = self.application.tracer.start_span(
                    operation_name='op', child_of=span_ctx, tags=rpc_tag
                )
            except Exception as e:
                # We failed to create a context, possibly due to no
                # incoming x-b3-*** headers. Start a fresh span.
                # Note: This is a fallback only, and will create fresh headers,
                # not propagate headers.
                span = self.application.tracer.start_span('op')
            with span_in_context(span):
                r = func(self, *args, **kw)
                return r
        wrapper.__name__ = func.__name__

        return wrapper

    return decorator


class BaseHandler(SessionBaseHandler):
    '''
    Handler处理类的基类
    '''
    

    
    def __init__(self, application, request, **kwargs):
        super(BaseHandler, self).__init__(application, request, **kwargs)
        
        self.log= application.log
        self.executor = application.executor

        self.db = application.db
        self.redis = application.redis
        
        self.err_msgs = application.error_msgs
        
        self._forward_headers = None    # 前一个调用的header.

    @property
    def session(self):
        '''
        此属性为重载SessionBaseHandler的方法
        :return:
        '''
        return self._create_mixin(self, '__session_manager', CeSessionManager)
    
    
    def on_finish(self):
        super(BaseHandler, self).on_finish()

    # @staticmethod
    def get_reurn_dict(self,code="CODE_OK",data=None):
        '''
        获取HTTP的返回的默认结果。
        :param code:
        :return:
        '''
    
        result = True
        if code != "CODE_OK":
            result = False
    
        return {
            'result': result,
            'code': self.err_msgs[code]['code'],
            'msg': self.err_msgs[code]['msg'],
            "data": data
        }
    
    def get_project_name_from_referer(self):
        '''
        从refere中获取项目名称。 其为http://sxxx.xxx/prject_name/xxxx/xxxxx
        :return:
        '''

        url_refer = self.request.headers.get('referer')
        if not url_refer:
            self.log.error('[get_project_name_from_referer][no_referer]')
            return None

        cur_prj_name = None
        url_parse_obj = urlparse(url_refer)
        url_path = url_parse_obj.path.split('/')
        if len(url_path) > 0:
            cur_prj_name = url_path[1]
            
        return cur_prj_name
    
    
    def get_forward_headers(self,froce=False):
        '''
        获取当前请求的关于istio相应的头信息。
        :return:    dict()
        '''
        
        if not self._forward_headers or froce:
            headers = {}
        
            # x-b3-*** headers can be populated using the opentracing span
            span = get_current_span()
            carrier = {}
            self.application.tracer.inject(
                span_context=span.context,
                format=Format.HTTP_HEADERS,
                carrier=carrier)
        
            headers.update(carrier)
            
            # 这个地方可以传一些自己的头，
            # We handle other (non x-b3-***) headers manually
            # if 'user' in session:
            #     headers['end-user'] = session['user']
        
            incoming_headers = ['x-request-id', 'x-datadog-trace-id', 'x-datadog-parent-id', 'x-datadog-sampled']
        
            # Add user-agent to headers manually
            if 'user-agent' in self.request.headers:
                headers['user-agent'] = self.request.headers.get('user-agent')
        
            for ihdr in incoming_headers:
                val = self.request.headers.get(ihdr)
                if val is not None:
                    headers[ihdr] = val
                    # print "incoming: "+ihdr+":"+val
                    
            self._forward_headers = headers
    
        return self._forward_headers