from pyrestful.rest import RestService
from mongoengine import connect,connection
from concurrent.futures import ThreadPoolExecutor
from pzutil.common.datetimeutils import MigrationTransformer
import pymongo
import redis
from jaeger_client import Tracer, ConstSampler
from jaeger_client.reporter import NullReporter
from jaeger_client.codecs import B3Codec
from opentracing.ext import tags
from opentracing.propagation import Format
from opentracing.scope_managers.tornado import TornadoScopeManager
import opentracing

def get_mongo(host_uri, db, host, authentication_source=None, replicaset=None,
              alias=connection.DEFAULT_CONNECTION_NAME, maxPoolSize=10, log=None):
    if log:
        log.info("[mongo_db][host:{}, db:{}]".format(host_uri, db))
    
    db_client = pymongo.MongoClient(host_uri, maxPoolSize=maxPoolSize)[db]
    db_client.add_son_manipulator(MigrationTransformer())
    
    connect(db=db, host=host, authentication_source=authentication_source,
            replicaset=replicaset,alias=alias)
    
    return db_client


def get_redis(host, password, port=6379,db=0, max_connections=20,log=None):
    '''
    获取redis连接。
    :param host:
    :param password:
    :param port:
    :param db:
    :param max_connections:
    :param log:
    :return:
    '''
    if log:
        log.info("[redis][host:{}, port:{}, db:{}]".format(host, port, db))
    
    pool = redis.ConnectionPool(
        host=host,
        port=port,
        db=db,
        password=password,
        max_connections=max_connections,
        decode_responses=True,
    )
    return redis.Redis(connection_pool=pool)

class BaApplication(RestService):
    def __init__(self, rest_handlers, resource=None, handlers=None, default_host="", transforms=None,
                 **settings):
        super(BaApplication, self).__init__(rest_handlers, resource=resource, handlers=handlers,
                                            default_host=default_host,
                                            transforms=transforms, **settings)
        self.log = settings["logger"]
        
        self.redis = None
        redis_conf = settings.get("redis",None)
        if redis_conf:
            self.redis = get_redis(log=self.log,**redis_conf)
            
        self._mongo = None
        mongo_conf = settings.get("mongo",None)
        if mongo_conf:
            self._mongo = get_mongo(log=self.log, **mongo_conf)
        
        #### 错误消息描述，格式如
        self.error_msgs = settings.get("error_msgs",{})
        if not self.error_msgs:
            # 如果这里提供的选项不足，请在构建BaApplication时通过参数传入。
            # 不要修改此基类定义，这里只是为了表明结构与定义。
            self.error_msgs = {
                'CODE_OK': {
                    'code': 200,
                    'msg': '正常'
                },
                "UNKNOW_ERROR": {
                    'code': 420,
                    'msg': '未知异常'
                },
                'No_AUTHENTICATION': {
                    'code': 421,
                    'msg': '登录已过期，请您重新登录'
                },
                'PARAMS_MISSING': {
                    'code': 431,
                    'msg': '参数缺失',
                }
            }
        
        # 下面这段是为完成istio的调用跟踪所需对象。
        # service_name为当前应用在YAML中定义的名称。
        self.service_name = settings.get("service_name",None)
        self._trace = None
        if self.service_name:
            self._trace = Tracer(
                one_span_per_rpc=True,
                service_name=self.service_name ,
                reporter=NullReporter(),
                sampler=ConstSampler(decision=True),
                scope_manager=TornadoScopeManager(),
                extra_codecs={Format.HTTP_HEADERS: B3Codec()}
            )
            opentracing.set_global_tracer(value=self._trace)
        
        exec_max_cnt = settings["EXECUTOR_MAX_COUNT"]
        self.executor = ThreadPoolExecutor(exec_max_cnt)
        
    @property
    def tracer(self):
        '''
        获取istio的调用跟踪所需对象。
        :return:
        '''
        
            
        return self._trace
        
    @property
    def db(self):
        return self._mongo