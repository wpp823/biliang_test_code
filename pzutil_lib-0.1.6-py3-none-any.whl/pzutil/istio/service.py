
import requests

class ServiceHTTPClient:
    
    ST_OK = 200
    
    def __init__(self, log, service_name, port,header_host,headers):
        self._log = log
        self._service_name = service_name
        self._port = port
        self._timeout = 10
        self._header_host = header_host
        
        self._headers = headers
        
        if not self._headers:
            self._headers = {}
        
        # 将header中增加Host的值。
        exist_host = self._headers.get("Host")
        if not exist_host and header_host:
            self._headers["Host"] = header_host
        else:
            
            if exist_host and header_host:
                self._log.warn("[ServiceHTTPClient][exist host({}) in header,so host({}) in paramete is not be used]"
                               .format(exist_host, header_host))
            elif exist_host and not header_host:
                self._log.warn("[ServiceHTTPClient][exist host({}) in header,and host in parameter is Null]".format(exist_host))
            elif not exist_host and not header_host:
                self._log.warn("[ServiceHTTPClient][host in header is Null,and host in parameter is all Null]")
            
        
    
    def _call_body(self, path, params=None, method="GET", files=None):
        '''
        实体调用方法
        :param path:
        :param headers: [dict]
        :param params:
        :param method:
        :return:
        '''
        
        if method.upper() == "POST":    # 为了兼容现有代码中关于POST的方法。
            return self._call_body_post(path=path, data=params, files=files)
        
        url = "http://{}:{}{}".format(self._service_name, self._port, path)
        res = None
        try:
            res = requests.request(method=method, url=url, headers=self._headers, params=params, timeout=self._timeout, files=files)
            self._log.info("[ServiceHTTPClient][method:{} url:{}][code:{}]".format(method, url, res.status_code))

        except BaseException:
            self._log.exception("[ServiceHTTPClient][url:{}][method:{}]".format(url, method))

        if res and res.status_code == 200:
            return 200, res.json()
        else:
            status = res.status_code if res is not None and res.status_code else 500
            return status, {'error': 'the service_name({}) occur error.url:{} status:{}, msg:{}'.format(self._service_name, url,status, res.text)}

    
    def _call_body_post(self, path, data, files=None):
        '''
        POST方法调用。
        :param path:
        :param data:    [dict] 作为POST方法的payload
        :param files:
        :return:
        '''
        
        url = "http://{}:{}{}".format(self._service_name, self._port, path)
        res = None
        try:
            res = requests.request(method="POST", url=url, headers=self._headers, data=data, timeout=self._timeout, files=files)
            
            self._log.info("[ServiceHTTPClient][method:POST url:{}][code:{}]".format(url, res.status_code))
        except BaseException:
            self._log.exception("[ServiceHTTPClient][url:{}][method:post]".format(url))

        if res and res.status_code == 200:
            return 200, res.json()
        else:
            status = res.status_code if res is not None and res.status_code else 500
            return status, {'error': 'the service_name({}) occur error.url:{} status:{}, msg:{}'.format(self._service_name, url,status, res.text)}
