__author__ = 'commissar'

NAME = "pzutil_lib"
VERSION = "0.1.6"