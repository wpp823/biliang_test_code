
import random
from qcloudsms_py import SmsSingleSender
from qcloudsms_py.httpclient import HTTPError

class QcloudSmsAuthCode(object):
    def __init__(self, sms_app_id, sms_app_key,sms_sign_name):
        self._sms_sign_name = sms_sign_name
        self.ssender = SmsSingleSender(sms_app_id, sms_app_key)

    def send_sms(self, area_code, phone_numbers, template_id):

        # 短信模板变量参数
        auth_code = self.get_random()
        params = [auth_code, '2']  # 当模板没有参数时，`params = []`
        res = self.ssender.send_with_param(int(area_code), phone_numbers, template_id=template_id,
                                           params=params, sign=self._sms_sign_name, extend="", ext="")  # 签名参数未提供或者为空时，会使用默认签名发送短信

        # TODO 业务处理
        if res['result'] == 0:
            return {
                'result': True,
                'code': auth_code
            }

        res['result_code'] = res['result']
        res['result'] = False
        res['msg'] = '发送短信失败'
        return res

    def send_sms_for_login_error(self, area_code, phone_numbers, template_id,service_telel):

        params = [phone_numbers[-4:], service_telel]  # 当模板没有参数时，`params = []`
        res = self.ssender.send_with_param(int(area_code), phone_numbers, template_id=template_id,
                                           params=params, sign=self._sms_sign_name, extend="",
                                           ext="")  # 签名参数未提供或者为空时，会使用默认签名发送短信

        # TODO 业务处理
        if res['result'] == 0:
            return {
                'result': True,
                # 'code': auth_code
            }

        res['result_code'] = res['result']
        res['result'] = False
        res['msg'] = '发送短信失败'
        return res

    def get_random(self):
        numbers = '1234567890'
        return ''.join(random.sample(numbers, 4))

