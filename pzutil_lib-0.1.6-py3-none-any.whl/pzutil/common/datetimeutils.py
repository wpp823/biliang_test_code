# -*- coding: utf-8 -*-
__author__ = 'wangyi'


from datetime import datetime
from datetime import timedelta
import pymongo
import time
import pytz
import re
from datetime import date
import json
import arrow

from pymongo.son_manipulator import SONManipulator


def dt2utc(_dt):
    '''
    将本地无时区的datetime 转为utc
    :param _dt:  本地无时区的datetime
    :return: utc datetime
    '''
    redt = None
    try:
        tz = pytz.timezone('Asia/Shanghai')
        redt = tz.localize(_dt).astimezone(pytz.utc)
    except:
        redt = _dt
    return redt

def utc2dt(_dt):
    '''
    utc to 本地时区的datetime
    :param _dt:  utc的datetime
    :return: local datetime
    '''
    redt = None
    try:
        _ts = dt2ts(_dt)
        _ts += 8*60*60
        redt =  ts2dt(_ts)
    except:
        redt = _dt
    return redt


def dtstr2ts(dt_str):
    '''
    字符串日期 转换为时间戳
    :param dt_str:   "%Y-%m-%d %H:%M:%S"
    :return: int 时间戳
    '''
    dt = datetime.strptime(dt_str,"%Y-%m-%d %H:%M:%S")
    return int(time.mktime(dt.timetuple()))


def dt2ts(dt):
    '''
    字符串日期 转换为时间戳
    :param dt:   datetime
    :return: int 时间戳
    '''
    return int(time.mktime(dt.timetuple()))

def ts2dt(ts):
    '''
    将时间戳转换为日期
    :param ts: 时间戳, 如果为毫秒值,将转换为秒级
    :return: datetime
    '''
    if len(str(ts)) == 13:
        ts = int(ts/1000.0)
    return datetime.fromtimestamp(ts)


def ts2dtstr(ts):
    '''
    将时间戳转换为日期字符串
    :param ts: 时间戳, 如果为毫秒值,将转换为秒级
    :return: datetime "%Y-%m-%d %H:%M:%S"
    '''
    if len(str(ts)) == 13:
        ts = int(ts/1000.0)
    dt =  datetime.fromtimestamp(ts)
    return dt.strftime("%Y-%m-%d %H:%M:%S")

def curr_ts():
    '''
    获取当前时间戳
    :return: 时间戳 int
    '''
    return int(time.time())
def curr_ts_milli():
    '''
    获取当前时间戳
    :return: 时间戳 int
    '''
    return int(time.time() * 1000)
def curr_dtstr():
    '''
    获取当前时间戳
    :return: 时间戳 int
    '''
    return ts2dtstr(int(time.time()))

def yestoday_dt():
    yestoday = int(time.time()) - 24 * 60 * 60
    yestoday = datetime.fromtimestamp(yestoday)
    return yestoday.strftime("%Y%m%d")

def baidu_str2dt(_dtstr):
    '''
    将当前文字描述的转化为时间
    :return:
    '''
    try:
        m_flag = u'''分钟前'''
        h_flag = u'''小时前'''
        if _dtstr.find(m_flag) != -1:
            s_at = _dtstr.index(m_flag)
            m_val = int(_dtstr[0:s_at].strip())
            ts = curr_ts() - m_val * 60
            return ts2dtstr(ts)

        if _dtstr.find(h_flag) != -1:
            s_at = _dtstr.index(h_flag)
            h_val = int(_dtstr[0:s_at].strip())
            ts = curr_ts() - h_val * 60 * 60
            return ts2dtstr(ts)

        dt = datetime.strptime(_dtstr, u"%Y年%m月%d日 %H:%M")
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except:
        #当输入无法处理的时间值,使用当前时间
        ts = curr_ts()
        return ts2dtstr(ts)

def baijia_str2dt(_dtstr):
    '''
    百家作者文章列表页,发布时间的填充
    :param _dtstr:
    07:50
    07-11
    2015-12-09
    :return:
    '''
    try:
        t_flag = ":"
        d_flag = "-"
        re_dt = ""
        if len(_dtstr) > 8:
            re_dt = "%s 00:00:00" % _dtstr
        elif _dtstr.find(t_flag) != -1:
            dt=  datetime.now()
            dt = dt.strftime("%Y-%m-%d")
            re_dt = "%s %s:00" % (dt,_dtstr)
        elif _dtstr.find(d_flag) != -1:
            dt = datetime.now()
            dt = dt.strftime("%Y")
            re_dt = "%s-%s 00:00:00" % (dt, _dtstr)
        else:
            re_dt = curr_dtstr()
    except:
        # 当输入无法处理的时间值,使用当前时间
        re_dt = curr_dtstr()
    return re_dt

def __regular_no_year(pub_at):
    '''
    针对“xx-xx”样式的格式化。
    :param pub_at:
    :return:
    '''
    re_mat_rule = re.match("^([01][\d])-([0123][\d])$",pub_at)    #for “xx-xx”
    if re_mat_rule:
        month = int(re_mat_rule.group(1))
        day = int(re_mat_rule.group(2))
        
        at_now = arrow.now()
        year = at_now.year
        
        while(True):
            at_first = arrow.get(year, month, day)
            tm_diff = at_now - at_first
            if tm_diff.total_seconds() > 0:
                break
            else:
                year = year - 1
        
        return "%d-%02d-%02d 00:00:00"%(year,month,day)
        
        dt = timedelta(days=days)
        rt = a - dt
        return rt.strftime("%Y-%m-%d %H:%M:%S")

    return None

def __regular_rule_year(pub_dt):
    '''
    针对“xxx 年 前”样式的格式化。
    :param pub_dt:  [string]去除了左右空格了且经过中间连接符都换成’-‘的。
    :return:
    '''
    re_mat_rule = re.match("^([\d]+)([\s]*)?年([\s]*)?前$",pub_dt)    #for “xxx 小 时 前”
    if re_mat_rule:
        days = int(re_mat_rule.group(1)) * 365

        a = datetime.now()
        dt = timedelta(days=days)
        rt = a - dt
        return rt.strftime("%Y-%m-%d %H:%M:%S")

    return None

def __regular_rule_month(pub_dt):
    '''
    针对“xxx 个 月 前”样式的格式化。
    :param pub_dt:  [string]去除了左右空格了且经过中间连接符都换成’-‘的。
    :return:
    '''
    re_mat_rule = re.match("^([\d]+)([\s]*)?(个)?月([\s]*)?前$",pub_dt)    #for “xxx 小 时 前”
    if re_mat_rule:
        days = int(re_mat_rule.group(1)) * 30

        a = datetime.now()
        dt = timedelta(days=days)
        rt = a - dt
        return rt.strftime("%Y-%m-%d %H:%M:%S")

    return None


def __regular_rule_week(pub_dt):
    '''
    针对“xxx 周 前”样式的格式化。
    :param pub_dt:  [string]去除了左右空格了且经过中间连接符都换成’-‘的。
    :return:
    '''
    re_mat_rule = re.match("^([\d]+)([\s]*)?周([\s]*)?前$",pub_dt)    #for “xxx 小 时 前”
    if re_mat_rule:
        wk = int(re_mat_rule.group(1))

        a = datetime.now()
        dt = timedelta(weeks=wk)
        rt = a - dt
        return rt.strftime("%Y-%m-%d %H:%M:%S")

    return None


def __regular_iso_timestr(dt_str):

    reg_dt_str = None
    try:
        dt = datetime.strptime(dt_str,'%a %b %d %H:%M:%S CST %Y')
        reg_dt_str = dt.strftime("%Y-%m-%d %H:%M:%S")

    except:
        pass

    return reg_dt_str


def __regular_rule_day(pub_dt):
    '''
    针对“xxx 天 前”样式的格式化。
    :param pub_dt:  [string]去除了左右空格了且经过中间连接符都换成’-‘的。
    :return:
    '''

    re_mat_rule = re.match("^([\d]+)([\s]*)?天([\s]*)?前$",pub_dt)    #for “xxx 小 时 前”
    if re_mat_rule:
        day = int(re_mat_rule.group(1))

        a = datetime.now()
        dt = timedelta(days=day)
        rt = a - dt
        return rt.strftime("%Y-%m-%d %H:%M:%S")

    return None

def __regular_rule_hour(pub_dt):
    '''
    针对“xxx 小 时 前”样式的格式化。
    :param pub_dt:  [string]去除了左右空格了且经过中间连接符都换成’-‘的。
    :return:
    '''

    re_mat_rule = re.match("^([\d]+)([\s]*)?小([\s]*)?时([\s]*)?前$",pub_dt)    #for “xxx 小 时 前”
    if re_mat_rule:
        hour = int(re_mat_rule.group(1))

        a = datetime.now()
        dt = timedelta(hours=hour)
        rt = a - dt
        return rt.strftime("%Y-%m-%d %H:%M:%S")

    return None


def __regular_rule_raw(pub_dt):
    '''
    针对“ymd”样式的格式化。
    :param pub_dt:  [string]去除了左右空格了且经过中间连接符都换成’-‘的。
    :return:
    '''

    re_mat_rule = re.match("^(20\d{2})(\d{2})(\d{2})$",pub_dt)
    if re_mat_rule:
        dt = "-".join(re_mat_rule.group(i) for i in range(1,4)) + (" 00:00:00")
        sf = datetime.strptime(dt, '%Y-%m-%d %H:%M:%S')
        return sf.strftime("%Y-%m-%d %H:%M:%S")

    return None


def datetime_regular(pub_dt):
    '''
    将一个字符串时间进行规则化，
    :param pub_dt:      [string]
    :return:    [string]规范化后的时间字符串“%Y-%m-%d %H:%M:%S”
    '''

    pub_dt = pub_dt.strip()
    pub_dt = pub_dt.replace('.','-')
    pub_dt = pub_dt.replace('/','-')
    servertime = time.time()
    da = datetime.fromtimestamp(servertime) #4月28日 08:16
    spilltime=str(pub_dt.strip(' '))
    sf = pub_dt

    if re.match(re.compile("今天[\w\W]*"), spilltime) :
         sf = da.strftime("%Y-%m-%d")+spilltime.replace("今天","") + ":00"
         sf = datetime.strptime(sf, '%Y-%m-%d %H:%M:%S')
         sf = sf.strftime("%Y-%m-%d %H:%M:%S")
    elif re.match(re.compile("昨天[\w\W]*"), spilltime) :
         mm = 60*60*24
         sf = datetime.fromtimestamp(servertime-mm).strftime("%Y-%m-%d %H:%M:%S")
    elif re.match(re.compile("[0-9]*分钟前"), spilltime) :
         # mm = (int(spilltime.replace("分钟前",""))+1)*60
         mm = int(spilltime.replace("分钟前",""))*60
         sf = datetime.fromtimestamp(servertime-mm).strftime("%Y-%m-%d %H:%M:%S")

    elif re.match(re.compile("[0-9]*小时前"), spilltime) :
         # mm = (int(spilltime.replace("小时前",""))+1)*60*60
         mm = int(spilltime.replace("小时前",""))*60*60
         sf = datetime.fromtimestamp(servertime-mm).strftime("%Y-%m-%d %H:%M:%S")
    elif re.match(re.compile("[0-9]{1,2}月[0-9]{1,2}日$"), spilltime) :
         spilltime = spilltime.replace("月", "-").replace("日", "")
         sf = da.strftime("%Y-")+spilltime+da.strftime(" 00:00:00")
         sf = datetime.strptime(sf,'%Y-%m-%d %H:%M:%S')
         sf = sf.strftime("%Y-%m-%d %H:%M:%S")
    elif re.match(re.compile("[0-9]{1,2}月[0-9]{1,2}日[\w\Ws]*"), spilltime) :
         spilltime = spilltime.replace("月", "-").replace("日", "")
         sf = da.strftime("%Y-")+spilltime+":00"
         sf = datetime.strptime(sf,'%Y-%m-%d %H:%M:%S')
         sf = sf.strftime("%Y-%m-%d %H:%M:%S")
    else:

        func_list = [
            __regular_iso_timestr,
            __regular_rule_hour,
            __regular_rule_day,
            __regular_rule_week,
            __regular_rule_month,
            __regular_rule_year,
            __regular_rule_raw,
            __regular_no_year
        ]

        for func in func_list:
            tmp_sf = func(spilltime)
            if tmp_sf:
                sf = tmp_sf
                break





    sf = sf.replace('年','-').replace('月','-').replace('日','')

    if len(sf) < 19:
        if ':' in sf:
            s=len(sf.split(':'))
            end=2*s+10
            subfomr='%Y-%m-%d %H:%M:%S'[0:end]
            if subfomr[end-1:] == '%':
                subfomr = '%Y-%m-%d %H:%M:%S'[0:end+1]
                sf = datetime.strptime(sf,subfomr).strftime('%Y-%m-%d %H:%M:%S')

        elif ' ' in sf :
             sf = datetime.strptime(sf,'%Y-%m-%d %H').strftime('%Y-%m-%d %H:%M:%S')
        else:
            sf = datetime.strptime(sf,'%Y-%m-%d').strftime('%Y-%m-%d %H:%M:%S')

    elif re.match(re.compile("[0-9]{4}-[0-9]{1,2}-[0-9]{1,2}\s[0-9]{1,2}:[0-9]{1,2}"),spilltime) :
         sf = datetime.strptime(spilltime, '%Y-%m-%d %H:%M:%S').strftime('%Y-%m-%d %H:%M:%S')

    elif re.match(re.compile("[0,9]{4}-[0,9]{1,2}-[0,9]{1,2}-(.)*"), spilltime) :
         sf = spilltime
         sf = datetime.strptime(sf,'%Y-%m-%d- %H:%M:%S')
         sf = sf.strftime("%Y-%m-%d %H:%M:%S")

    day_pref = da.strftime('%Y-%m-%d %H:%M:%S')
    sf = sf + day_pref[len(sf):]
    sf = datetime.strptime(sf,'%Y-%m-%d %H:%M:%S').strftime('%Y-%m-%d %H:%M:%S')
    return sf

#
# def datetime_regular(pub_dt):
#     pub_dt = pub_dt.strip()
#     pub_dt = pub_dt.replace('.','-')
#     pub_dt = pub_dt.replace('/','-')
#     servertime = time.time()
#     da = datetime.fromtimestamp(servertime) #4月28日 08:16
#     spilltime=str(pub_dt.strip(' '))
#     sf = pub_dt
#
#     if re.match(re.compile("今天[\w\W]*"), spilltime) :
#          sf = da.strftime("%Y-%m-%d")+spilltime.replace("今天","") + ":00"
#          sf = datetime.strptime(sf, '%Y-%m-%d %H:%M:%S')
#          sf = sf.strftime("%Y-%m-%d %H:%M:%S")
#
#     elif re.match(re.compile("昨天[\w\W]*"), spilltime) :
#          mm = 60*60*24
#          sf = datetime.fromtimestamp(servertime-mm).strftime("%Y-%m-%d %H:%M:%S")
#     elif re.match(re.compile("[0-9]*分钟前"), spilltime) :
#          mm = (int(spilltime.replace("分钟前",""))+1)*60
#          sf = datetime.fromtimestamp(servertime-mm).strftime("%Y-%m-%d %H:%M:%S")
#
#     elif re.match(re.compile("[0-9]*小时前"), spilltime) :
#          mm = (int(spilltime.replace("小时前",""))+1)*60*60
#          sf = datetime.fromtimestamp(servertime-mm).strftime("%Y-%m-%d %H:%M:%S")
#
#     elif re.match(re.compile("[0-9]{1,2}月[0-9]{1,2}日[\w\Ws]*"), spilltime) :
#          sf = da.strftime("%Y-")+spilltime+":00"
#          sf = datetime.strptime(sf,'%Y-%m-%d %H:%M:%S')
#          sf = sf.strftime("%Y-%m-%d %H:%M:%S")
#
#     sf = sf.replace('年','-').replace('月','-').replace('日','')
#
#     if len(sf) < 19:
#         if ':' in sf:
#             s=len(sf.split(':'))
#             end=2*s+10
#             subfomr='%Y-%m-%d %H:%M:%S'[0:end]
#             if subfomr[end-1:] == '%':
#                 subfomr = '%Y-%m-%d %H:%M:%S'[0:end+1]
#                 sf = datetime.strptime(sf,subfomr).strftime('%Y-%m-%d %H:%M:%S')
#
#         elif ' ' in sf :
#              sf = datetime.strptime(sf,'%Y-%m-%d %H').strftime('%Y-%m-%d %H:%M:%S')
#         else:
#             sf = datetime.strptime(sf,'%Y-%m-%d').strftime('%Y-%m-%d %H:%M:%S')
#
#     elif re.match(re.compile("[0-9]{4}-[0-9]{1,2}-[0-9]{1,2}\s[0-9]{1,2}:[0-9]{1,2}"),spilltime) :
#          sf = datetime.strptime(spilltime, '%Y-%m-%d %H:%M:%S').strftime('%Y-%m-%d %H:%M:%S')
#
#     elif re.match(re.compile("[0,9]{4}-[0,9]{1,2}-[0,9]{1,2}-(.)*"), spilltime) :
#          sf = spilltime
#          sf = datetime.strptime(sf,'%Y-%m-%d- %H:%M:%S')
#          sf = sf.strftime("%Y-%m-%d %H:%M:%S")
#
#     day_pref = da.strftime('%Y-%m-%d %H:%M:%S')
#     sf = sf + day_pref[len(sf):]
#     sf = datetime.strptime(sf,'%Y-%m-%d %H:%M:%S').strftime('%Y-%m-%d %H:%M:%S')
#     return sf

class CJsonEncoder(json.JSONEncoder):
    '''
    json dumps 使用  cls= CJsonEncoder  序列化日期类型数据
    '''
    def default(self, obj):
        if isinstance(obj, datetime):
            return obj.strftime('%Y-%m-%d %H:%M:%S')
        elif isinstance(obj, date):
            return obj.strftime('%Y-%m-%d')
        else:
            return json.JSONEncoder.default(self, obj)


class MigrationTransformer(pymongo.son_manipulator.SONManipulator):
    '''
    此类用于序列化datetime到mongo中。
    '''
    
    def _encode_date(self, value):
        return datetime.datetime.combine(
            value,
            datetime.datetime.min.time())
    
    def _handle_list(self, value):
        for index, item in enumerate(value):
            if isinstance(item, dict):
                value[index] = self._handle_dict(item)
            elif isinstance(item, list):
                value[index] = self._handle_list(item)
            elif isinstance(item, datetime.date):
                value[index] = self._encode_date(item)
        return value
    
    def _handle_dict(self, item):
        for (key, value) in item.items():
            if type(value) == datetime.date:
                item[key] = self._encode_date(value)
            elif isinstance(value, dict):  # recurse into sub-docs
                item[key] = self._handle_dict(value)
            elif isinstance(value, list):  # recurse into sub-docs
                item[key] = self._handle_list(value)
        return item
    
    def transform_incoming(self, son, collection):
        for (key, value) in son.items():
            # datetime.datetime is instance of datetime.date
            # compare type explicitly only
            if type(value) == datetime.date:
                son[key] = self._encode_date(value)
            elif isinstance(value, dict):  # recurse into sub-docs
                son[key] = self.transform_incoming(value, collection)
            elif isinstance(value, list):  # recurse into sub-docs
                son[key] = self._handle_list(value)
        return son
    
    def transform_outgoing(self, son, collection):
        return super(MigrationTransformer, self).transform_outgoing(son, collection)

if __name__ == "__main__":
    # a = (baidu_str2dt(u"4分钟前"))


    a = datetime.now()
    print(utc2dt(a))
    # print a
    # print type(a)
    # print dt2utc(a)
    print(datetime_regular("Fri May 26 18:06:38 CST 2017"))
    print(datetime_regular("07-11"))
    print(datetime_regular("昨天"))
    print(datetime_regular("1小时前"))
    print(datetime_regular("1小时 前"))
    print(datetime_regular("1天 前"))
    print(datetime_regular("1周 前"))
    print(baidu_str2dt(u"20小时前"))
    print(baidu_str2dt(u"2016年06月24日 07:00"))
    print(baidu_str2dt("我都不知道这里是啥样的值,分钟前,小时前,2016年06月24日 07:002016年06月24日 07:002016年06月24日 07:002016年06月24日 07:00"))
    print(curr_dtstr()[:-6])
    print(baijia_str2dt("07:50"))
    print(baijia_str2dt("07-11"))
    print(baijia_str2dt("2015-12-09"))
    print(datetime_regular("1 月前"))
    print(datetime_regular("1 年前"))
    print(datetime_regular("20170521"))
    # print(datetime_regular("30150871"))
    # create_time = params["art_dt"][:11] + soup.find('span', attrs={'class': 'time'}).text[-5:] + ':00'
    # print(baijia_str2dt("2015-12-09")[:11] + u"07月13日 07:50"[-5:] + ":00")
    pass



