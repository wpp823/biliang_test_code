from torndsession.session import SessionManager

class CeSessionManager(SessionManager):
    '''
    对原来的sessionManager进行扩展。主要为了向cookie中写一个标识，用于标识这个用户是可用于灰度发布的用户。
    '''
    
    PREFIX_SESSION = "ts_"  # session_id的前缀
    
    def __init__(self, handler):
        super(CeSessionManager, self).__init__(handler=handler)

    
    def _session_settings(self):
        session_settings = self.settings.get('cookie_config', {})
        session_settings.setdefault('expires', None)
        session_settings.setdefault('expires_days', None)
        return session_settings
    
    def _generate_session_id(self, blength=24):
        '''
        重载session_id的生成，使其有固定前缀
        :param blength:
        :return:
        '''
        _preix_session = self.settings.get('session_prefix', CeSessionManager.PREFIX_SESSION)   # 默认session的前缀
        cur_len = blength - len(_preix_session)
        session_id = super(CeSessionManager, self)._generate_session_id(blength=cur_len)
        return "{}{}".format(_preix_session, session_id)
    
    def delete(self, key):
        super(CeSessionManager, self).delete(key=key)
        
        
    @property
    def expires_second(self):
        '''
        返回秒为单位的生命时间。
        :return:
        '''
        
        return int(self.settings.get('session_lifetime', self.DEFAULT_SESSION_LIFETIME))
        
        
    def get_session_object_by_session_id(self, session_id) -> dict:
        '''
        根据session_id获取到session对象。
        :param session_id:
        :return:
        '''
    
        return self._get_session_object_from_driver(session_id=session_id)