
from.array_connection import connection_from_list_slice
import graphene

from graphene_mongo.fields import MongoengineConnectionField
from graphene_mongo.utils import get_node_from_global_id


class MgConnectionField(MongoengineConnectionField):
    def __init__(self, type, *args, **kwargs):
        super(MgConnectionField, self).__init__(
            type, *args, **kwargs
        )

    def default_resolver(self, _root, info, **args):

        args = args or {}

        connection_args = {
            "first": args.pop("first", None),
            "last": args.pop("last", None),
            "before": args.pop("before", None),
            "after": args.pop("after", None),
            "page": args.pop("page", None),
            "page_size": args.pop("page_size", None),
        }

        _id = args.pop("id", None)

        if _id is not None:
            iterables = [get_node_from_global_id(self.node_type, info, _id)]
            list_length = 1
        elif callable(getattr(self.model, "objects", None)):
            iterables = self.get_queryset(self.model, info, **args)
            list_length = iterables.count()
        else:
            iterables = []
            list_length = 0

        connection = connection_from_list_slice(
            list_slice=iterables,
            args=connection_args,
            list_length=list_length,
            connection_type=self.type,
            edge_type=self.type.Edge,
            pageinfo_type=graphene.PageInfo,
        )
        connection.iterable = iterables
        connection.list_length = list_length
        return connection


