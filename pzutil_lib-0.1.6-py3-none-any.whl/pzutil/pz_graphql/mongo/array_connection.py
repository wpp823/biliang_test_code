import math

from graphql_relay.connection.arrayconnection import (
    get_offset_with_default,
    offset_to_cursor,
)
from graphql_relay.connection.connectiontypes import (
    Connection,
    PageInfo,
    Edge,
)

from pzutil.pz_graphql.mongo.relay.connectiontypes import PageSizeInfo


def connection_from_list_slice(
        list_slice,
        args=None,
        connection_type=None,
        edge_type=None,
        pageinfo_type=None,
        slice_start=0,
        list_length=0,
        list_slice_length=None,
        connection_field=None):
    """
    Given a slice (subset) of an array, returns a connection object for use in
    GraphQL.
    This function is similar to `connectionFromArray`, but is intended for use
    cases where you know the cardinality of the connection, consider it too
    large to materialize the entire array, and instead wish pass in a slice of
    the total result large enough to cover the range specified in `args`.
    """
    connection_type = connection_type or Connection
    edge_type = edge_type or Edge

    args = args or {}

    if args.get('page') or args.get('page_size'):
        conn = size_page_connection(list_slice,args=args,
        connection_type=connection_type,
        edge_type=edge_type,
        pageinfo_type=PageSizeInfo)
    else:
        pageinfo_type = pageinfo_type or PageInfo
        conn = cursor_page_connection(list_slice,
                    args=args,
                    connection_type=connection_type,
                    edge_type=edge_type,
                    pageinfo_type=pageinfo_type,
                    slice_start=slice_start,
                    list_length=list_length,
                    list_slice_length=list_slice_length)

    return conn


def cursor_page_connection(list_slice,
                           args=None,
                           connection_type=None,
                           edge_type=None,
                           pageinfo_type=None,
                           slice_start=0,
                           list_length=0,
                           list_slice_length=None):
    connection_type = connection_type or Connection
    edge_type = edge_type or Edge
    pageinfo_type = pageinfo_type or PageInfo

    args = args or {}

    before = args.get('before')
    after = args.get('after')
    first = args.get('first')
    last = args.get('last')
    if list_slice_length is None:
        list_slice_length = len(list_slice)
    slice_end = slice_start + list_slice_length
    before_offset = get_offset_with_default(before, list_length)
    after_offset = get_offset_with_default(after, -1)

    start_offset = max(
        slice_start - 1,
        after_offset,
        -1
    ) + 1
    end_offset = min(
        slice_end,
        before_offset,
        list_length
    )
    if isinstance(first, int):
        end_offset = min(
            end_offset,
            start_offset + first
        )
    if isinstance(last, int):
        start_offset = max(
            start_offset,
            end_offset - last
        )

    # If supplied slice is too large, trim it down before mapping over it.
    _slice = list_slice[
             max(start_offset - slice_start, 0):
             list_slice_length - (slice_end - end_offset)
             ]
    edges = [
        edge_type(
            node=node,
            cursor=offset_to_cursor(start_offset + i)
        )
        for i, node in enumerate(_slice)
        ]

    first_edge_cursor = edges[0].cursor if edges else None
    last_edge_cursor = edges[-1].cursor if edges else None
    lower_bound = after_offset + 1 if after else 0
    upper_bound = before_offset if before else list_length

    return connection_type(
        edges=edges,
        page_info=pageinfo_type(
            start_cursor=first_edge_cursor,
            end_cursor=last_edge_cursor,
            has_previous_page=isinstance(last, int) and start_offset > lower_bound,
            has_next_page=isinstance(first, int) and end_offset < upper_bound
        )
    )



def size_page_connection(list_slice,
                        args=None,
                        connection_type=None,
                        edge_type=None,
                        pageinfo_type=PageSizeInfo,list_length=0,
                        list_slice_length=None):


    page = args.get('page', 1)
    page_size = args.get('page_size', 10)

    offset_start = (page - 1) * page_size
    offset_end = offset_start + page_size

    # If supplied slice is too large, trim it down before mapping over it.
    _slice = list_slice[offset_start:offset_end]

    edges = [
        edge_type(
            node=node,
            cursor=offset_to_cursor(offset_start + i)
        )
        for i, node in enumerate(_slice)
        ]

    if list_slice_length is None:
        list_slice_length = len(list_slice)

    page_total = math.ceil(list_slice_length/page_size)

    conn = connection_type(
        edges=edges,
        page_size_info=pageinfo_type(
            total=list_slice_length,
            pageTotal=page_total,
            page=page,
            pageSize=page_size,
        )
    )

    return conn