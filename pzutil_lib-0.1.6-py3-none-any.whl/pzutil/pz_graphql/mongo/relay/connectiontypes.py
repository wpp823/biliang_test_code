
class Connection(object):

    def __init__(self, edges, page_info=None, page_size_info=None, facets=None):
        self.edges = edges
        self.page_info = page_info
        self.page_size_info = page_size_info
        self.facets = facets

    def to_dict(self):
        return {
            'edges': [e.to_dict() for e in self.edges],
            'pageInfo': self.page_info.to_dict(),
            'pageSizeInfo': self.page_size_info.to_dict(),
            'facets': {}
        }


class PageSizeInfo(object):

    def __init__(self, total=int, pageTotal=int, page=int, pageSize=int):
        self.total = total
        self.pageTotal = pageTotal
        self.page = page
        self.pageSize = pageSize

    def to_dict(self):
        return {
            'total': self.total,
            'pageTotal': self.pageTotal,
            'page': self.page,
            'pageSize': self.pageSize,
        }

