
import re
from collections import (
    # Iterable,
    OrderedDict,
)
from graphene.types import (
    # Boolean,
    Enum,
    Int,
    Interface,
    List,
    NonNull,
    Scalar,
    String,
    Union,
)
from graphene.types.field import Field
from graphene.types.objecttype import ObjectType, ObjectTypeOptions

from graphene.relay import PageInfo
from graphene.relay import Connection


class Facets(ObjectType):
    class Meta:
        description = (
            "The Relay compliant `Facets` type, containing facets data."
        )


class ConnectionOptions(ObjectTypeOptions):
    node = None


class PageSizeInfo(ObjectType):
    class Meta:
        description = (
            "The Relay compliant `PageInfo` type, containing data necessary to"
            " paginate this connection."
        )

    total = Int(
        required=True,
        name="total",
        description="总数据数",
    )

    page = Int(
        required=True,
        name="page",
        description="当前页",
    )

    pageTotal = Int(
        name="pageTotal",
        description="总页数",
    )

    pageSize = Int(
        name="pageSize",
        description="每页条数",
    )


class MgConnection(Connection):
    class Meta:
        abstract = True

    @classmethod
    def __init_subclass_with_meta__(cls, node=None, name=None, **options):
        _meta = ConnectionOptions(cls)
        assert node, "You have to provide a node in {}.Meta".format(cls.__name__)
        assert isinstance(node, NonNull) or issubclass(
            node, (Scalar, Enum, ObjectType, Interface, Union, NonNull)
        ), ('Received incompatible node "{}" for Connection {}.').format(
            node, cls.__name__
        )

        base_name = re.sub("Connection$", "", name or cls.__name__) or node._meta.name
        if not name:
            name = "{}Connection".format(base_name)

        edge_class = getattr(cls, "Edge", None)
        _node = node

        class EdgeBase(object):
            node = Field(_node, description="The item at the end of the edge")
            cursor = String(required=True, description="A cursor for use in pagination")

        class EdgeMeta:
            description = "A Relay edge containing a `{}` and its cursor.".format(
                base_name
            )

        edge_name = "{}Edge".format(base_name)
        if edge_class:
            edge_bases = (edge_class, EdgeBase, ObjectType)
        else:
            edge_bases = (EdgeBase, ObjectType)

        edge = type(edge_name, edge_bases, {"Meta": EdgeMeta})
        cls.Edge = edge

        options["name"] = name
        _meta.node = node
        _meta.fields = OrderedDict(
            [
                (
                    "page_size_info",
                    Field(
                        PageSizeInfo,
                        name="PageSizeInfo",
                        required=True,
                        description="Pagination data for this connection.",
                    ),
                ),
                (
                    "page_info",
                    Field(
                        PageInfo,
                        name="pageInfo",
                        required=True,
                        description="Pagination data for this connection.",
                    ),
                ),
                (
                    "edges",
                    Field(
                        NonNull(List(edge)),
                        description="Contains the nodes in this connection.",
                    ),
                ),
            ]
        )
        return super(Connection, cls).__init_subclass_with_meta__(
            _meta=_meta, **options
        )
