from typing import List

from thing_client.istio import ServiceHTTPClient

SS_SPU_STATUS_ON = 5  # 商品状态 上架

SS_SPU_NEED_EDIT_ONLINE = 0  # 获取线上数据
SS_SPU_NEED_EDIT_DRAFT = 1  # 获取草稿数据


class ProductClient(ServiceHTTPClient):

    def __init__(self, log, service_name, port, header_host, headers):
        super().__init__(log, service_name, port, header_host, headers)
        self.log = log
        self._service_name = service_name
        self._port = port
        self._header_host = header_host
        self._timeout = 30
        
    def search(self, keyword, count, page=0, keyword_cate='title'):
        '''
        进行商品搜索。
        :param keyword:
        :param count:
        :return:
        '''
        
        info_api = '/in/mnc/api/v1/spu/search'
        params_data = {
            "keyword": keyword,
            "page": page,
            "page_size": count,
            'keyword_cate': keyword_cate,
            # "sort_by":'normal'
        }
        
        try:
            status, res = self._call_body(path=info_api, params=params_data)
            if status == 200:
                self.log.info("[ProductClient.search][params_data:{}][res:{}]".format(params_data, res))
                return res.get('data', [])
            else:
                self.log.error("[ProductClient.search][params_data:{}][status:{}, res:{}]".format(params_data,status, res))
        except:
            self.log.error('[ProductClient][search][params_data:{}]'.format(params_data))
            return []
    
        
        
        
        

    def get_product_id_list(self, status, page, page_size) -> List:
        """
        # 获微信端商品id列表
        :param status: 产品状态
        :param page:
        :param page_size:
        :return:
        """

        info_api = '/in/mnc/api/v1/spu/products'
        params_data = {
            "status": status,
            "page": page,
            "page_size": page_size,
            "need_edit_spu": SS_SPU_NEED_EDIT_ONLINE,
        }

        try:
            status, res = self._call_body(path=info_api, params=params_data)
            if status == 200:
                self.log.info("[ProductClient.get_product_id_list][res:{}]".format(res))
                return res.get('data', [])

        except:
            self.log.error('[ProductClient][sync_product_data_error][params_data:{}]'.format(params_data))
            return []

    def sync_product_spu_data(self, product_id) -> bool:
        """
        调用产品同步接口
        :param product_id:
        :return:
        """
        sync_api = '/in/mnc/api/v1/spu/product/sync'

        data = {
            "product_id": product_id
        }
        try:
            re_status, res = self._call_body_post(path=sync_api, data=data)

        except:
            self.log.error('[ProductClient][sync_product_data_error][product_id:{}]'.format(product_id))
            return False

        if re_status == 200:
            self.log.info("[ProductClient.aync_product_spu_data][product_id:{}]".format(product_id))
            return True

