from typing import List

from pzutil.istio.service import ServiceHTTPClient
from Nightcrawler_client.conf import ApiResultObj
from Nightcrawler_client.constant import SELF_STATUS_MAP, SS_SELL_SELF


class OrderClient(ServiceHTTPClient):

    def __init__(self, log, service_name, port, header_host, headers):
        super().__init__(log, service_name, port, header_host, headers)
        self.log = log
        self._service_name = service_name
        self._port = port
        self._header_host = header_host

    def get_order_id_list(self, start_update_time, end_update_time, status, page, page_size) -> List:
        """
        获取订单id列表
        :param source:
        :param start_update_time: e.g:2021-11-13 09:31:41
        :param end_update_time:e.g: 2021-11-13 09:31:41
        :param status:
        :param page:
        :param page_size:
        :return:
        """

        info_api = '/in/mnc/api/v1/order/list'

        params_data = {
            "start_update_time": start_update_time,
            "end_update_time": end_update_time,
            "status": status,
            "page": page,
            "page_size": page_size,
            "source": SS_SELL_SELF
        }

        try:
            status, res = self._call_body(path=info_api, params=params_data)
            if status == 200:
                self.log.info("[OrderClient.get_order_id_list][res:{}]".format(res))
                return res.get('data', [])

        except:
            self.log.error('[OrderClient][get_order_id_list_error][params_data:{}]'.format(params_data))
            return []

    def sync_order_data(self, order_id) -> bool:
        """
        订单状态同步接口
        :param order_id:
        :return:
        """
        info_api = '/in/mnc/api/v1/order/sync'

        data = {
            "order_id": order_id
        }
        try:
            re_status, res = self._call_body_post(path=info_api, data=data)

        except:
            self.log.error('[OrderClient][sync_order_data_error][product_id:{}]'.format(order_id))
            return False

        if re_status == 200:
            self.log.info("[OrderClient.sync_order_data][order_id:{}]".format(order_id))
            return True

    def sync_order_begin_time(self) -> str:
        """
        获取同步开始时间
        :return: 2021-11-13 09:31:41
        """
        sync_api = '/in/mnc/api/v1/order/sync/max/time'

        try:
            re_status, res = self._call_body(path=sync_api)

        except:
            self.log.error('[OrderClient][sync_order_begin_time_error][]')
            return ""

        if re_status == 200:
            self.log.info("[OrderClient.sync_order_begin_time]")
            data = res.get('data', "")
            if data.get("update_time"):
                return data.get("update_time")

            return ""

    def get_info(self, order_id):
        '''
        获取某个订单的信息。
        :param order_id:
        :return:
        '''

        api = "/in/mnc/api/v1/order/info"
        data = {
            "order_id": order_id
        }
        try:
            re_status, res = self._call_body(path=api, params=data)

        except:
            self.log.exception('[OrderClient][get_info_error][product_id:{}]'.format(order_id))
            return {}

        if re_status != 200:
            self.log.error("[OrderClient.get_info][order_id:{},res:{}]".format(order_id, res))

        return res.get("data", {})

    def get_order_recommand_id(self, user_id, product_id):
        '''
        获取某个订单的推荐者。
        :param user_id:
        :param product_id:
        :return:
        '''

        api = "/in/mnc/api/v1/order/recommand"
        data = {
            "user_id": user_id,
            "product_id": product_id
        }

        recommand_id = None
        try:
            re_status, res = self._call_body(path=api, params=data)

        except:
            self.log.exception('[OrderClient][get_order_recommand_error][param:{}]'.format(data))
            return recommand_id

        if re_status != 200:
            self.log.error("[OrderClient.get_order_recommand_id][param:{},res:{}]".format(data, res))
        else:
            recommand_id = res.get("data", {}).get("recommand_id", None)
        return recommand_id


def order_status_to_human(status):
    '''
    订单的状态到可读状态。
    :param status:
    :return:
    '''

    self_status = SELF_STATUS_MAP.get(status, None)
    return self_status
