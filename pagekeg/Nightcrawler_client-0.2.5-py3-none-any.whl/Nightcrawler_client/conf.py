


class ApiResultData:
    err_msgs = {
        'CODE_OK': {
            'code': 200,
            'msg': '正常'
        },
        'No_AUTHENTICATION': {
            'code': 421,
            'msg': '登录已过期，请您重新登录'
        },
        'REQUEST_FAILURE': {
            'code': 424,
            'msg': '请求失败',
        }
    }

    def get_reurn_dict(self, code="CODE_OK", data=None):
        '''
        获取HTTP的返回的默认结果。
        :param code:
        :return:
        '''

        result = True
        if code != "CODE_OK":
            result = False

        return {
            'result': result,
            'code': self.err_msgs[code]['code'],
            'msg': self.err_msgs[code]['msg'],
            "data": data
        }


class ApiResultObj:
    """
    返回结果
    """
    def __init__(self, result=False, msg=None, code=200, **kwargs):
        self._result = result
        self._code = code
        self._msg = msg
        self._kwargs = kwargs

    @property
    def result(self):
        return self._result

    @property
    def code(self):
        return self._code

    @property
    def msg(self):
        return self._msg

    def get_data(self):
        return self._kwargs




