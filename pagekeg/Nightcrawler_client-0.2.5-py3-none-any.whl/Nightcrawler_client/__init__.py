

NAME = "Nightcrawler_client"
VERSION = "0.2.5"