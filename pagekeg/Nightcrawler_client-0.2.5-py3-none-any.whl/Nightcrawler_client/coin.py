
class CoinBank:
    def __init__(self, log):
        self._log = log
        
        
    def money_2_coin(self, val):
        '''
        钱转积分
        :param val: [int]   单位分：
        :return:
        '''
        
        # ！！！  1万积分是1元。

        # val /100 * 10000 简化如下:
        return val * 100