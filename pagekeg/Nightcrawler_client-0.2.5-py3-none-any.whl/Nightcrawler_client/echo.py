from typing import List

from pzutil.istio.service import ServiceHTTPClient
from Nightcrawler_client.conf import ApiResultObj
from Nightcrawler_client.constant import SELF_STATUS_MAP, SS_SELL_SELF

class EchoClient(ServiceHTTPClient):

    def __init__(self, log, service_name, port, header_host, headers):
        super().__init__(log, service_name, port, header_host, headers)
        self._timeout = 30
    
    def echo(self, echo,sleep):
        api_uri = '/in/mnc/api/v1/echo'
    
        params_data = {
            "echo": echo,
            "sleep": sleep,
        }
    
        try:
            status, res = self._call_body(path=api_uri, params=params_data)
            if status == 200:
                self._log.info("[EchoClient.echo][res:{}]".format(res))
                return res.get('data', {})
            else:
                self._log.error('[EchoClient.echo][params_data:{}]'.format(params_data))
    
        except:
            self._log.exception('[EchoClient.echo][params_data:{}]'.format(params_data))
            return {}
