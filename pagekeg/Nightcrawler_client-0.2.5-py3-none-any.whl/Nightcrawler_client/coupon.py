from typing import Dict

from pzutil.istio.service import ServiceHTTPClient


class CouponClient(ServiceHTTPClient):

    def __init__(self, log, service_name, port, header_host, headers):
        super().__init__(log, service_name, port, header_host, headers)
        self.log = log
        self._service_name = service_name
        self._port = port
        self._header_host = header_host

    def push_coupon(self, user_id, coupon_type, coupon_val) -> Dict:
        """
        向某人下发优惠券

        :param user_id:
        :type user_id:
        :param coupon_type:
        :type coupon_type:
        :param coupon_val:
        :type coupon_val:
        :return: {'coupon_id': coupon_id}
        :rtype:
        """

        info_api = '/in/mnc/api/v1/coupon/grant'

        params_data = {
            "user_id": user_id,
            "coupon_type": coupon_type,
            "coupon_val": coupon_val,
        }

        try:
            status, res = self._call_body(path=info_api, params=params_data)
            if status == 200:
                self.log.info("[CouponClient.push_coupon][res:{}]".format(res))
                return res.get('data', {})

        except:
            self.log.error('[CouponClient.push_coupon_fail][params_data:{}]'.format(params_data))
            return {}

    def get_coupon_msg(self, coupon_id) -> Dict:
        """
        获取优惠券信息

        :param coupon_id:
        :type coupon_id:
        :return:
         {
            'discount_fee': discount_fee,  # 优惠券值多少钱
            'coupon_type': coupon_type,  # 优惠券类型。
        }
        :rtype:
        """

        info_api = '/in/mnc/api/v1/coupon/info'

        params_data = {
            "coupon_id": coupon_id,
        }

        try:
            status, res = self._call_body(path=info_api, params=params_data)
            if status == 200:
                self.log.info("[CouponClient.get_coupon_msg][params_data:{},res:{}]".format(params_data, res))
                return res.get('data', {})
        except:
            self.log.error('[CouponClient.get_coupon_msg_fail][params_data:{}]'.format(params_data))
            return {}

    def get_overdue_coupon_list(self, start_update_time, end_update_time, status, page, page_size):
        """
        获取过期优惠券

        :param start_update_time:
        :type start_update_time:
        :param end_update_time:
        :type end_update_time:
        :param status:
        :type status:
        :param page:
        :type page:
        :param page_size:
        :type page_size:
        :return:
        :rtype:
        """

        info_api = '/in/mnc/api/v1/coupon/list'

        params_data = {
            "start_update_time": start_update_time,
            "end_update_time": end_update_time,
            "status": status,
            "page": page,
            "page_size": page_size,
        }

        try:
            status, res = self._call_body(path=info_api, params=params_data)
            if status == 200:
                self.log.info("[CouponClient.get_coupon_id_list][res:{}]".format(res))
                return res.get('data', [])

        except:
            self.log.error('[CouponClient][get_coupon_id_list_error][params_data:{}]'.format(params_data))
            return []

    def sync_coupon_data(self, coupon_id) -> bool:
        """
        同步优惠券

        :param coupon_id:
        :type coupon_id:
        :return:
        """
        info_api = '/in/mnc/api/v1/coupon/sync'

        data = {
            "coupon_id": coupon_id
        }
        try:
            re_status, res = self._call_body_post(path=info_api, data=data)

        except:
            self.log.error('[CouponClient][sync_coupon_data_error][coupon_id:{}]'.format(coupon_id))
            return False

        if re_status == 200:
            self.log.info("[CouponClient.sync_coupon_data][coupon_id:{}]".format(coupon_id))
            return True

    def get_sync_coupon_begin_time(self) -> str:
        """
        获取同步开始时间

        :return: 2021-11-13 09:31:41
        """
        sync_api = '/in/mnc/api/v1/coupon/sync/max/time'

        try:
            re_status, res = self._call_body(path=sync_api)

        except:
            self.log.error('[CouponClient][get_sync_coupon_begin_time]')
            return ""

        if re_status == 200:
            self.log.info("[CouponClient.sync_coupon_begin_time]")
            data = res.get('data', "")
            if data.get("update_time"):
                return data.get("update_time")
            return ""

    def auto_coupon_overdue_recovery(self, start_create_time, end_create_time,begin,limit):
        """
        过期优惠券自动返还

        :param start_create_time:
        :type start_create_time:
        :param end_create_time:
        :type end_create_time:
        :return:
        :rtype:
        """

        info_api = '/in/mnc/api/v1/coupon/recovery'

        data = {
            "start_create_time": start_create_time,
            "end_create_time": end_create_time,
            "begin": begin,
            "limit": limit,
        }

        try:
            status, res = self._call_body_post(path=info_api, data=data)
            if status == 200:
                self.log.info("[CouponClient.auto_coupon_overdue_recovery][res:{}]".format(res))
                return res

        except:
            self.log.error('[CouponClient][auto_coupon_overdue_recovery_error][params_data:{}]'.format(data))
            return {}