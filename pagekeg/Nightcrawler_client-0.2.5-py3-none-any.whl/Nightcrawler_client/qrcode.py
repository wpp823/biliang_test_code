import json

from thing_client.istio import ServiceHTTPClient

SS_SPU_STATUS_ON = 5  # 商品状态 上架

SS_SPU_NEED_EDIT_ONLINE = 0  # 获取线上数据
SS_SPU_NEED_EDIT_DRAFT = 1  # 获取草稿数据


class QrcodeClient(ServiceHTTPClient):

    def __init__(self, log, service_name, port, header_host, headers):
        super().__init__(log, service_name, port, header_host, headers)
        self.log = log
        self._service_name = service_name
        self._port = port
        self._header_host = header_host
        self._timeout = 30
        
        
    def get_article_qrcode(self, article_id,emp_id):
        '''
        
        :param article:
        :return:
        '''

        info_api = '/in/mnc/api/v1/qrcode'
        params_data = {
            "params": json.dumps({'a':article_id}),
            "path": 'pages/media_wiki_detail/media_wiki_detail',
            'project_name':'xlkk',
            'emp_id':emp_id,
        }

        try:
            status, res = self._call_body(path=info_api, params=params_data)
            if status == 200:
                self.log.info("[QrcodeClient.get_article_qrcode][params_data:{}][res:{}]".format(params_data, res))
                return res.get('data', {})
            else:
                self.log.error(
                    "[QrcodeClient.get_article_qrcode][params_data:{}][status:{}, res:{}]".format(params_data, status, res))
                return {}
        except:
            self.log.error('[QrcodeClient][get_article_qrcode][params_data:{}]'.format(params_data))
            return {}

    def get_dialy_qrcode(self,dialy_id,emp_id):
        """
        获取日记分享二维码

        :param dialy_id:
        :param emp_id:
        :return:
        """

        info_api = '/in/mnc/api/v1/qrcode'
        params_data = {
            "params": json.dumps({'a':dialy_id}),
            "path": 'pages/media_dialy_detail/media_dialy_detail',
            'project_name': 'xlkk',
            'emp_id': emp_id,
        }

        try:
            status, res = self._call_body(path=info_api, params=params_data)
            if status == 200:
                self.log.info("[QrcodeClient.search][params_data:{}][res:{}]".format(params_data, res))
                return res.get('data', {})
            else:
                self.log.error(
                    "[QrcodeClient.get_dialy_qrcode][params_data:{}][status:{}, res:{}]".format(params_data, status, res))
                return {}
        except:
            self.log.error('[QrcodeClient][get_dialy_qrcode][params_data:{}]'.format(params_data))
            return {}

    def get_qa_qrcode(self,answer_id,emp_id):
        """
        获取问答分享二维码

        :param answer_id:
        :param question_id:
        :param emp_id:
        :return:
        """

        info_api = '/in/mnc/api/v1/qrcode'
        params_data = {
            "params": json.dumps({'a': answer_id}),
            "path": 'pages/media_answer_detail/media_answer_detail',
            'project_name': 'xlkk',
            'emp_id': emp_id,
        }

        try:
            status, res = self._call_body(path=info_api, params=params_data)
            if status == 200:
                self.log.info("[QrcodeClient.get_qa_qrcode][params_data:{}][res:{}]".format(params_data, res))
                return res.get('data', {})
            else:
                self.log.error(
                    "[QrcodeClient.get_qa_qrcode][params_data:{}][status:{}, res:{}]".format(params_data, status, res))
                return {}
        except:
            self.log.error('[QrcodeClient][get_qa_qrcode][params_data:{}]'.format(params_data))
            return {}

